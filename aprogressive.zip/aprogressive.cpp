#include <iostream>
#include  <fstream>


using namespace std;
ifstream fin ("aprogressive.in");
ofstream out ("aprogressive.out");
int main() {
int m ,n,T,C,k,nr,V[10000];
cin >>C;
if(C==1)
{ fin>>n>>m; int maxim=0,ok=0,l;
    for(int i=1;i<=n;i++) {
        int nr = 0;
   for (int j=1;j<=m;j++)
   {   fin>>k;
   nr+=k;}
   if(nr>maxim)
   {maxim=nr;l=i;}
   V[i]=nr;
   if(nr==maxim)
       ok++;

    }
    if(ok==0)
        out<<l;
    else
        for(int i=1;i<=n;i++)
        {   if(V[i]==maxim)
             out<<i;
            }
}


}
